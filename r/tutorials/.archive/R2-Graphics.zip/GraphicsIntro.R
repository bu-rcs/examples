## ------------------------------ ##
##  Graphics in R
##  Data Analysis and Visualization
##
## Scientific Computing and Visualization
## ------------------------------ ##

## List all available packages
library()

## Load MASS package
library(MASS)

## List datasets
data()

## Load trees dataset into workspace
data(trees)

## View first few lines of the dataset
head(trees)

## Get data dimensions
dim(trees)

## Get column (variables) names
names(trees)

##Get help/description for the dataset
?trees

## Display the structure of the dataset
str(trees)

## Get the length of a variable (vector)
length(trees$Height)

## Get type of the variable
mode(trees$Height)

## Are there any missing data
length(trees$Height[is.na(trees$Height)])

## Explore some statistics
summary(trees$Height)

## Stemplots
stem(trees$Girth)
stem(trees$Volume)

## Change scale of the stemplot
stem(trees$Volume, scale = .5)

## Display a histogram
hist(trees$Height)

##  List all available output devices 
dev.list()

## Check which device is current. If no device is active, returns 1 - a "null device"
dev.cur()

## To switch between devices use dev.set(n) command

## Saving graphics into a file
## R supports a number of formats including JPG, PNG, WMF, PDF, Postscript...

hist(trees$Height)                 #plot
dev.copy(png, "myHistogram.png")   # copy to device
dev.off()                          # release the device

png("myHistogram.png")  # specify the output device and format
hist(trees$Height)      # plot to device
dev.off()               # release the device

## Read in a dataset
pop <- read.csv("population.csv")
head(pop)
str(pop)

pop$Race <- factor(pop$Race, labels=c("Other", "Hispanic","White","African","Asian"))
str(pop)
table(pop$Race)

## Pie charts
pie(table(pop$Race))

## Get Help on piechart
?pie

## Get an example of pie chart
example(pie)

## Enhance pie chart
pct <- round(table(pop$Race)/sum(table(pop$Race))*100)  # calculate percentage of each category
lbls <- levels(pop$Race)                                # make labels
lbls <- paste(lbls,pct)                                 # add percentage value to the label
lbls <- paste(lbls, "%", sep="")                       # add percent sign at the end
pie(table(pop$Race), labels = lbls, col = rainbow(length(lbls)), main="Race")


# Barplots
barplot(table(pop$Race), main="Race")

b <- barplot(table(pop$Race), main="Race", ylim = c(0,200), col=terrain.colors(5))
text(x=b, y=table(pop$Race), labels = table(pop$Race), pos=3, col="black", cex=1.25)

# use patterns instead of colors
b <- barplot(table(pop$Race), main="Race", ylim = c(0,200), angle = 15 + 30*1:5, density = 20)
text(x=b, y=table(pop$Race), labels = table(pop$Race), pos=3, col="black", cex=1.25)

#use shades of grey
b <- barplot(table(pop$Race), main="Race", ylim = c(0,200), col=gray.colors(5))
text(x=b, y=table(pop$Race), labels = table(pop$Race), pos=3, col="black", cex=1.25)

# Side-by-side plot
m1 <- tapply(pop$Wage, pop$Union, mean)
m2 <- tapply(pop$Wage, pop$Union, median)
r <- rbind(m1,m2)
b<- barplot(r, col = c("forestgreen", "orange"), 
            ylim=c(0,12),beside=T,
            ylab="Wage (dollars per hour)", 
            names.arg=c("non-union","union"))

# Add a legend
legend("topleft", c("mean","median"),
       col = c("forestgreen","orange"),
       pch = 15)  # use square symbol for the legend

# Add text
text(b, y = r, labels=format(r,4),
     pos = 3,     # above of the specified coordinates
     cex = .75)  # character size

# Boxplot
boxplot(pop$Wage, main="Wage, sollars per hour", horizontal = TRUE)

# compare wages of two groups
boxplot(pop$Wage ~ pop$Sex, main="Wages among male and female workers")

# add colors
boxplot(pop$Wage ~ pop$Sex, 
        main="Wages among male and female workers",
        col=c("forestgreen","orange"))

# A Histogram
hist(pop$Wage)

hist(pop$Wage,
     col = "grey",
     border = "black",
     main = "Wage distribution",   
     xlab = "Wage, (dollars per hour)",
     breaks = seq(0,50,by=2) )
rug(pop$Wage)    # Add rugplot to the graphics


# Display probability density
hist(pop$Wage,
     col = "grey",
     border = "black",
     main = "Wage distribution",   
     xlab = "Wage, (dollars per hour)",
     breaks = seq(0,50,by=2),
     freq = F)
rug(pop$Wage)    # Add rugplot to the graphics

# Add lines displaying a kernel density and a legend:
hist(pop$Wage,
     col = "grey",
     border = "black",
     main = "Wage distribution",   
     xlab = "Wage, (dollars per hour)",
     breaks = seq(0,50,by=2),
     freq = F)
rug(pop$Wage)    # Add rugplot to the graphics
lines(density(pop$Wage),lwd=1.5)
lines(density(pop$Wage, adj=2),
        lwd=1.5, # line width
        col = "brown") 
lines(density(pop$Wage, adj=0.5),
      lwd=1.5, 
      col = "forestgreen")


legend("topright",
       c("Default","Double","Half"),
       col=c("black", "brown", "forestgreen"),
       pch = 16, 
       title="Kernel Density Bandwidth")

# If only lines are desired
plot(density(pop$Wage),
     col="darkblue", 
     main="Kernel .", 
     xlab="Wage .",
     lwd=1.5,
     ylim=c(0,0.12) )
lines(density(pop$Wage),lwd=1.5)
lines(density(pop$Wage, adj=2),
      lwd=1.5, # line width
      col = "brown") 
lines(density(pop$Wage, adj=0.5),
      lwd=1.5, 
      col = "forestgreen")


legend("topright",
       c("Default","Double","Half"),
       col=c("black", "brown", "forestgreen"),
       pch = 16, 
       title="Kernel Density Bandwidth")

# Plot Empirical cumulative distribution
plot(ecdf(pop$Wage),
     pch=1, 
     col="darkblue",
     xlab="Wage, dollars per hour",
     main="Empirical CDF")
grid()  # add grid

# Lets look at the dogs dataframe
dogs <- read.csv("dogs.csv")

# Plot a scatterplot
plot(dogs$height~dogs$weight,
     main="Weight-Height relationship")

# Enhanced scatterplot
plot(dogs$height[dogs$sex=="F"]~
     dogs$weight[dogs$sex=="F"],
     col="darkred",
     pch=1,
     main="Weight-Height Diagram",
     xlim=c(80,240),
     ylim=c(55,75),
     xlab="weight, lb", 
     ylab="height, inch")
points(dogs$height[dogs$sex=="M"]~ dogs$weight[dogs$sex=="M"],
       col="darkblue",
       pch=2)
legend("topleft",                       # add legend
       c("Female", "Male"),
       col=c("darkred","darkblue"),
       pch=c(1,2),
       title="Sex")
# add best-fit line
abline(lm(dogs$height~dogs$weight),
       col="forestgreen",
       lty=2)
# add text
text(80, 56, "Best-fit line: y = 0.088x + 52.32",
     col="forestgreen",
     pos=4)
# plot mean point for the cluster of female dogs
points(mean(dogs$weight[dogs$sex=="F"]),
       mean(dogs$height[dogs$sex=="F"]),
       col="black",
       bg="red",
       pch=23)
# plot mean point for the cluster of male dogs
points(mean(dogs$weight[dogs$sex=="M"]),
       mean(dogs$height[dogs$sex=="M"]),
       col="black",
       bg="lightblue",
       pch=23)
# add grid 
grid()
# add horizontal line
abline( h = 63 )
# add vertical line
abline( v = 131 )


#pick points
pts<- identify(dogs$weight,dogs$height)


# several graphs 
# specify number of rows and columns in the table
par( mfrow = c(1,2) ) 
hist(dogs$age, main="Age" )
barplot(table( dogs$dog_type), main="Dog types" )
# return to normal display
par( mfrow = c(1,1) ) 

# Matrix of scatterplots
pairs( ~height+weight+age,  
       data = dogs, 
       main="Age, Height and weight scatterplots" )



               