##
## =============  Input and Output of Datasets ==============
##
## R Tutorial
## Katia Oleinik, 2015
## Research Computing
## Boston University
##
## =======================================================

## ***********************
##    Read CSV file
## ***********************

# Read simple comma delimited file (csv) - assumes presence of the header
dataset <- read.csv("Datasets/marscrater.csv")

# *** row.names ***
# Use a variable in the dataset as a row name
dataset <- read.csv("Datasets/marscrater.csv",
                    row.names="CRATER_ID")

# *** stringsAsFactors ***
# Surpress converting string variables into factors
# Use a variable in the dataset as a row name
dataset <- read.csv("Datasets/marscrater.csv",
                    row.names="CRATER_ID",
                    stringsAsFactors=FALSE)

### PERFORMANCE TIP ###
# *** nrows *** colClasses ***
# If the dataset is large, provide columns types and record number if possible
# a mild overestimate is possible for record number
# For this dataset the time is cut almost twice!
dataset <- read.csv(file = "Datasets/marscrater.csv",
                    row.names = "CRATER_ID",
                    stringsAsFactors = FALSE,
                    nrows = 384344,
                    colClasses = c(rep("character",2),rep("numeric",4),rep("character",3),"integer"))

# *** na.strings ***
# Specify values that should be converted to NA (missing values)
# Here all blank cells in string columns will be converted to NA
dataset <- read.csv(file = "Datasets/marscrater.csv",
                    row.names = "CRATER_ID",
                    stringsAsFactors = FALSE,
                    nrows = 384344,
                    colClasses = c(rep("character",2),rep("numeric",4),rep("character",3),"integer"),
                    na.strings = c("", "NAN"))

## ***********************
# Advanced packages to load datasets 
# This finctions are often much faster for large datasets, but might require
# some extra settings to deal with poorly formatted input files
# Each package below performs significantly faster than the standard read.* functions and
# noramlly is easier to use, but might fail for some non-standard input formats
## ***********************
require(data.table)
dataset <- fread ( input = "Datasets/gapminder.csv" )

require(readr)
dataset <- read_csv( file = "Datasets/marscrater.csv" )

# compare the time it takes this dataset to be loaded by the regular read.csv and readr packages
system.time(dataset <- read.csv(file = "Datasets/marscrater.csv",
                                row.names = "CRATER_ID",
                                stringsAsFactors = FALSE,
                                nrows = 384344,
                                colClasses = c(rep("character",2),rep("numeric",4),rep("character",3),"integer"),
                                na.strings = c("", "NAN")))
system.time (dataset <- read_csv( file = "Datasets/marscrater.csv" ))


## **********************************
##    Read TXT file (tab delimeted)
## **********************************

# Read simple tab delimited file (txt) - assumes presence of the header
# Unlike csv read.table assumes no header by default
# we also have to specify the delimeter charaster (space - by default)
dataset <- read.table("Datasets/TabDelim.txt",
                      header = TRUE,
                      sep = "\t")

# In this example we would like to leave Sex variable as factor, but 
#     Name variable should be set as character
dataset <- read.table("Datasets/TabDelim.txt",
                      header = TRUE,
                      sep = "\t",
                      colClasses = c("integer","character",rep("integer",3),"factor"))

### PERFORMANCE TIP ###
# read.table will work faster for large files if comment.char is set as ""
dataset <- read.table("Datasets/TabDelim.txt",
                      header = TRUE,
                      sep = "\t",
                      colClasses = c("integer","character",rep("integer",3),"factor"),
                      comment.char = "")

# In some cases file might contain a few lines that would want to skip
# Here is an example of the file that does not have a header, but has a few lines
# explaining the dataset
# This file also contains some blank line we would like to skip
dataset <- read.table("Datasets/TabDelim1.txt",
                      header = FALSE,
                      sep = "\t",
                      colClasses = c("integer","character",rep("integer",3),"factor"),
                      comment.char = "",
                      skip = 8,
                      blank.lines.skip = TRUE)
names(dataset) <- c("ID","Name","Age","Height","Weight","Gender")

## *********************************
##    Read TXT file (fixed width)
## *********************************
dataset <- read.fwf("Datasets/FixedWidth.txt",
                      widths = c(12,19,8,11,11,6),
                      col.names = c("ID","Name","Age","Height","Weight","Gender"))

## ***************************
##    Read Excel files 
## ***************************
# some libraries to read Excel files:
#   RODBC (for 32-bit version only)
#   xlsx
#   gdata
#   xlsReadWrite (32-bit version only)
library("xlsReadWrite")
xls.getshlib()
dataset <- read.xls("Datasets/gapminder.xls")

# Warning: Excel files cannot be opened/edited on Linux, so for portability
#   it is always better to convert the data into csv format

# Excel (and other sources) data can also be read from a Clipboard:
# Open Excel file, select and copy the cells and then run the code

# here we assume the first record is a header
clip <- readClipboard()
clip <- strsplit(clip, "\t")
dataset <- as.data.frame(do.call(rbind, clip[-1]), stringsAsFactors=FALSE)
names(dataset) <- clip[[1]]

# if no header is present in the selected cells
clip <- readClipboard()
clip <- strsplit(clip, "\t")
dataset <- as.data.frame(do.call(rbind, clip), stringsAsFactors=FALSE)

## ***************************
##    Read SAS files 
## ***************************
# Libraries to read SPSS files:
#   - foreign (read.spss() function)
#   - Hmisc() (sasxport.get())

# if SAS is installed on the system, read ssd or sas7bdat file
library("foreign")
dataset <- read.ssd(library = "Datasets", 
                    sectionnames = "gapminder",
                   sascmd = "C:/Program Files/SAS/SASFoundation/9.3/sas.exe")

# if SAS is not installed on the computer use SAS export file
library("foreign")
library("Hmisc")
dataset <- sasxport.get("Datasets/gapminder.xpt") 


## ***************************
##    Read SPSS files 
## ***************************
# Libraries to read SPSS files:
#   - foreign (read.spss() function)
#   - Hmisc (spss.get() function)
library("foreign")
dataset <- read.spss("Datasets/gapminder.sav",
                    use.value.labels = TRUE,
                    to.data.frame    = TRUE)

## ***************************
##    Read Stata files 
## ***************************
library("foreign")
dataset <- read.dta("Datasets/gapminder.dta")


## *************************************
##    Read from the current program
## *************************************
#  1). read using stdin()
# End the input with a blank line
dataset <- read.csv( stdin() )
ID,NAME,AGE,HEIGHT,WEIGHT,SEX
10001,Thomas Reed,54,172,80,MALE
10002,Diana Brown,36,165,65,FEMALE
10003,Joshua Louville,75,170,90,MALE
10004,Raymond Santos,30,180,82,MALE
10005,Alexandra Trolard,28,162,55,FEMALE
10006,Evana Bilkey,78,158,48,FEMALE

# LEAVE ABOVE LINE BLANK !!!
dataset

# 2). read from a character string
dataset <-
  "ID,NAME,AGE,HEIGHT,WEIGHT,SEX
10001,Thomas Reed,54,172,80,MALE
10002,Diana Brown,36,165,65,FEMALE
10003,Joshua Louville,75,170,90,MALE
10004,Raymond Santos,30,180,82,MALE
10005,Alexandra Trolard,28,162,55,FEMALE
10006,Evana Bilkey,78,158,48,FEMALE"
dataset <- read.csv( textConnection(dataset) )

## =======================================================

# Saving the datasets

# Create a directory for the output (optional)
dir.create("Output", showWarnings = FALSE, recursive = TRUE)

## =======================================================



## ***********************
##    Write to  CSV file
## ***********************

# Read simple comma delimited file (csv) - assumes presence of the header
write.csv( dataset,
           file = "Output/myDataset.csv")

# Supress writting row names into output file
write.csv( dataset,
           file = "Output/myDataset.csv",
           row.names=FALSE)


## ***********************
##    Write to  txt file
## ***********************

write.table(dataset,
            file = "Output/myDataset.txt",
            quote = FALSE, # do not use quotes aorund string variables
            sep = "\t",    # use tab as a separator
            na  = " ",     # output missing values with a space
            row.names = TRUE,
            col.names = TRUE)

## ***********************
##    Load an R script
## ***********************
source("myRscript.R")

# for verbose output use option echo
source("myRscript.R", echo=TRUE)

## ***********************
##    Directed output (cannot be used to output graphics!)
## ***********************

# Direct output into a file
sink("Output/myOutpoutFile.txt", append = FALSE)

   ## some code
   a <- rnorm(10)
   paste(" Length of a = ",length(a))

# Close file and return output to the terminal
sink()

# Direct output into both - a file and terminal
sink("Output/myOutpoutFile.txt", append = FALSE, split = TRUE)

## some code
a <- rnorm(10)
paste(" Length of a = ",length(a))

# Close file and return output to the terminal
sink()