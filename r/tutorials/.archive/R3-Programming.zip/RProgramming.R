## -------------------------------------------- ##
##
##   Programming in R
##
## Scientific Computing and Visualization Group
## Katia Oleinik 
## --------------------------------------------- ##


## ------------ ##
## if
## ------------ ##

x <- 7

# simple if statement
if( x > 0) print ("Positive")

# simple if-else statement
if( x > 0) print ("Positive") else print ("Non-negative")

# using if for assignment
y <- if( x < 0) -1 else 0
print(y)

# Multiline if statement
if ( x < 0) {
  x <- x - 10
  print("x is negative: subtract ten")
} else if ( x==0 ) {
  print("x is equal to zero")
} else {
  x <- x + 10 
  print("x is positive: add ten")
}


## ------------ ##
## ifelse
## ------------ ##

# simple ifelse statement
(y <- ifelse ( x < 0, -1, 0 ))

# nested ifelse statement
(y <- ifelse ( x < 0, -1, ifelse (x > 0, 1, 0) ))

# ifelse operates on vectors!
digits <- 0:9
(odd <- ifelse (digits%%2 > 0, TRUE, FALSE))

## ********** ##
##  exercise  ##
## ********** ##
## using ifelse calculate abs(x)
(y <- ifelse()  )



## ------------ ##
## switch
## ------------ ##
x <- 3
switch (x, 2, 4, 6, 8)
switch (x, 2, 4)

# switch with named list
day <- "Tue"
switch( day, Sun = 0, Mon = 1, Tue = 2, Wed = 3, Thu = 4, Fri = 5, Sat = 6, Sun = 7)

# switch statement with a default value
food <- "meet"
switch (food, banana="fruit", carrot="veggie", "neither")




## ------------ ##
## repeat & break
## ------------ ##
x <- 84
repeat{
    print(x)
    if (x %% 2 != 0) break
    x <- x/2
}




## ------------ ##
## for loop
## ------------ ##

# print all words in a vector
names <- c("Sam", "Paul", "Michael")
for( j in names ){ 
  print(paste("My name is", j))
}




## ------------ ##
## while loop
## ------------ ##
x <- 84
print(x)
while ( x%%2 == 0) {
  x <- x/2
  print(x)
}
  

## ********** ##
##  exercise  ##
## ********** ##
# using either loop calculate n!




## ------------ ##
## functions
## ------------ ##

# simple function: calculate (x+1)^2
myFun <- function (x) {
  x^2 + 2*x + 1
}
myFun(3)

# function with optional argument
myFun <- function (x, a = 1) {
  x^2 + 2*x*a + a^2
}
myFun(3)
myFun(3,2)
myFun( a = 2, x = 1)


# Passing optional argument into function
myFun <- function (x, ... ){
  y <-  table(x)
  barplot(y, ...)
}
sex <- c ("Male", "Male", "Female", "Male", "Female")
myFun(sex)
myFun(sex, main="Sex", col=c("forestgreen", "orange"))

# Another example of function with optional arguments
myPrint <- function ( ...) {
  print(paste( ...) )
}
myPrint("Hello",",","R!")


## ********** ##
##  exercise  ##
## ********** ##
# write a function that calculates geometric mean of avectors
# geometric mean is (x1 *x2 *x3 ... *xn) ^ (1/n)
# hint: use function prod()
geo.mean<-function( v ){
  
}
# define a vector
x <- c(27, 8, 125)

# calculate geometric mean of a vector and print the result


## --------------------------- ##
## local and global variables
## --------------------------- ##
myFun <-function (x) {
  cat ("u=", u, "\n")
  u <- u+1
  cat ("u=", u, "\n")
}
u <- 2    # define a variable
myFun(5)  # execute the function
print(u)

## access global variable - AVOID CHANGING GLOBAL VARIABLES
myFun <-function (x) {
  cat ("u=", u, "\n")
  u <<- u+1
  cat ("u=", u, "\n")
}
u <- 2    # define a variable
myFun(5)  # execute the function
print(u)

## Functions do not change their arguments
myFun <- function (x) {
  x <- 2
  cat ("Inside the function x=", x, "\n")
  return (x)
}
x <- 3
myFun(x)
cat ("After the function x=", x, "\n")

# reassign x value caluclated inside the function
x <- 3
x <- myFun(x)
cat ("After the function x=", x, "\n")

## --------------------------- ##
## Exploring R source code
## --------------------------- ##
lm
mean
methods("mean")
mean.default



## Load some data
dt<-read.csv("USA_states.csv",
             col.names=c("state", "location", "pop", "area", "house","ap", "traffic","ed","cancer","cigar","date"),
             colClasses=c("character","factor","integer","numeric",rep("integer",2),"numeric","factor","numeric","numeric","character"))


## --------------------------- ##
## apply() 
## --------------------------- ##
x <- matrix( 1:12, nrow = 3, ncol = 4)   # create a 3 x 4 matrix
x
apply (x, 1, sd)  # calculate sd for rows
apply (x, 2, median)    # calculate median columns
apply (x, c(1,2), function(x) x%%2 )

myFun <- function (x) {
  x <- x+2
}
apply (x, c(1,2), myFun )

## calculate varience for 3rd, 4th, and 6th column in the dataset
apply(dt[ ,c(3,4,6)], 2, var)

## to find row (column) sum or mean use highly optimized
## colMeans, rowMeans, colSums, rowSums

## --------------------------- ##
## lapply() 
## --------------------------- ##
# create a list
x <- list(a = 1:10, beta = exp(-3:3), logic = c(TRUE,FALSE,FALSE))

# compute  mean for each list element
lapply(x, mean)

## --------------------------- ##
## sapply() 
## --------------------------- ##
# create a list
x <- list(a = 1:10, beta = exp(-3:3), logic = c(TRUE,FALSE,FALSE))

# compute the mean for each list element
sapply(x, mean)


## --------------------------- ##
## tapply() 
## --------------------------- ##

## tapply(Summary Variable, Group Variable, Function)
tapply(dt$traffic, dt$ed, mean)

## ********** ##
##  exercise  ##
## ********** ##
## find medium population (dt$pop) for each USA region (dt$location)
tapply( )


## --------------------------- ##
## aggregate()
## --------------------------- ##
# The aggregate function splits the data into subsets and 
# computes summary statistics for each of them. 
# The output of aggregate is a data.frame
aggregate(subset(dt, select=c("pop", "area")), subset(dt, select=location), summary)


## A few more functions convinient it managing the subsets:
## merge()
## split(), unsplit(), by()
## ddply()           from package plyr
## summaryBy()       from package doBy
## sqldf()           from package sqldf


## --------------------------- ##
## code sourcing
## --------------------------- ##
##
## simple source
source("foo.R")
x<- c(3,5,7)
foo(x)

## source with echo
source("foo.R", echo=TRUE)
x<- c(3,5,7)
foo(x)


## ------------------- ##
## timing
## ------------------- ##
myFun <- function(n){    
  y <- vector(length=n)
  for (i in 1:n) y[i] = i/(i+1)
  y
}
system.time( myFun(1000000) )

## ----------------- ##
## code optimization
## ----------------- ##
myFunOpt <- function(x){
  x/(x+1)
}
x <- 1:1000000
system.time( myFunOpt(x) )


## ----------------------------- ##
## expanding arrays dynamically
## ----------------------------- ##
N <- 100000
vec1 <- NULL
system.time( for(i in 1:N) vec1 <- c(vec1, mean(1:100)))

vec2 <- vector(mode="numeric", length = N)
system.time( for(i in 1:N) vec2[i] <- mean(1:100))


## ------------------------------- ##
## rowSums(), rowMeans(), table, etc.
## ------------------------------- ##
N <- 5000000
matx <- matrix (rnorm(N), N/10, 10)

system.time(apply(matx,1,mean))
system.time(rowMeans(matx))


## ------------------------------- ##
## user written function sometimes can run faster than a system one!
## ------------------------------- ##
system.time(for(i in 1:100000)mean(1:100))
system.time(for(i in 1:100000)sum(1:100)/length(1:100))

## ------------------------------- ##
## Brownian motion simulation
## ------------------------------- ##
source("bm.R")

# simulate 1000 steps
Nsteps <- 10000
system.time( BMpos <- bmslow(c(0,0),Nsteps))
system.time( BMpos <- bm(c(0,0),Nsteps))
  
# plot the result
x11()
plot(BMpos[1,],BMpos[2,], type="l")
points(BMpos[1,1],BMpos[2,1], pch = 19, col="green")
points(BMpos[1,Nsteps],BMpos[2,Nsteps], pch = 19, col="red")
graphics.off()

# load compiler library (if you have not done it before)
require (compiler)

# compile function from a source file 
bmc <- cmpfun (bm)

# check the time again
system.time( BMpos <- bmc(c(0,0),Nsteps))

## ------------------------------- ##
## Profiling
## ------------------------------- ##
source("bm.R")

# start profiling slow function
Rprof( )   # optional - provide output file name
#Rprof("bmslow.out")   # optional - provide output file name

# run function
Nsteps <- 10000
BMS <- bmslow(c(0,0), Nsteps) 

# finish profiling
Rprof(NULL)
# Print the summary
summaryRprof()

# profile a faster version
Rprof() 

# run function
Nsteps <- 10000
BMS <- bm(c(0,0), Nsteps) 

# finish profiling
Rprof(NULL)
# profiling summary
summaryRprof()

unlink("bmslow.out")  # delete temporary file
unlink("bm.out")      # delete temporary file



